from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
import datetime
import os
from datetime import date, datetime, timedelta

app = Flask("myapp")
app.secret_key = os.urandom(64)

db_path = 'db/database.db'

with sqlite3.connect(db_path, check_same_thread=False) as db:
    cursor = db.cursor()

    #query_del1 = """DROP TABLE events"""
    #query_del2 = """DROP TABLE users"""
    query_init1 = """ CREATE TABLE IF NOT EXISTS events(
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT NOT NULL, 
        desc TEXT, 
        takeplace TEXT NOT NULL, 
        datetime_beg TIMESTAMP NOT NULL, 
        datetime_end TIMESTAMP NOT NULL, 
        organizer TEXT
        ) """
    query_init2 = """ CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT NOT NULL,
        phone TEXT NOT NULL, 
        pwd TEXT NOT NULL,
        role INTEGER DEFAULT 0 
        )  """
    query_check1 = """SELECT COUNT(*) FROM events"""
    query_check2 = """SELECT COUNT(*) FROM users"""
    query_info = """PRAGMA table_info({table_name})"""
    query_del = """DELETE FROM {table_name} WHERE {primary_key} = ?"""
    query_indef1 = """
            INSERT OR IGNORE INTO events (id, name, desc, takeplace, datetime_beg, datetime_end, organizer) VALUES (?, ?, ?, ?, ?, ?, ?)
            """
    query_indef2 = """
            INSERT OR IGNORE INTO users (id, name, phone, pwd, role) VALUES (?, ?, ?, ?, ?)
            """
    query_insert = """INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"""
    query_gtn = """SELECT name FROM sqlite_master WHERE type='table';"""
    query_gtd = """SELECT * FROM {table_name}"""

    def get_table_names():
        cursor.execute(query_gtn)
        tables = cursor.fetchall()
        return [table[0] for table in tables]

    def get_table_data(table_name):
        try:
            cursor.execute(f"""SELECT * FROM {table_name}""")
            columns = [description[0] for description in cursor.description]
            data = cursor.fetchall()
        except sqlite3.Error as e:
            print(f"Error reading table {table_name}: {e}")
            columns = []
            data = []
        
        return columns, data

    def get_primary_key(table_name):
        cursor.execute(f"""PRAGMA table_info({table_name})""")
        columns = cursor.fetchall()
        for column in columns:
            if column[5] == 1:
                return column[1]
        return None

    def get_table_schema(table_name):
        cursor.execute(f"""PRAGMA table_info({table_name})""")
        columns = cursor.fetchall()
        schema = []
        for column in columns:
            schema.append({
                'name': column[1],
                'type': column[2],
                'notnull': column[3],
                'default_value': column[4],
                'pk': column[5]
            })
        return schema

    def insert_row(table_name, data):
        try:
            schema = get_table_schema(table_name)
            primary_key = get_primary_key(table_name)
            
            filtered_data = {k: v for k, v in data.items() if k != primary_key}
            
            columns = ', '.join(filtered_data.keys())
            placeholders = ', '.join(['?' for _ in filtered_data])
            
            cursor.execute(f"""INSERT INTO {table_name} ({columns}) VALUES ({placeholders})""", list(filtered_data.values()))
            db.commit()
            return True
        except sqlite3.Error as e:
            print(f"Error inserting row: {e}")
            db.rollback()
            return False
        
    def delete_row(table_name, primary_key, primary_key_value):
        try:
            cursor.execute(f"""DELETE FROM {table_name} WHERE {primary_key} = ?""", (primary_key_value,))
            db.commit()
            return True
        except sqlite3.Error as e:
            print(f"Error deleting row: {e}")
            db.rollback()
            return False

    def initialize_database():
        
        cursor.execute(query_init1)
        
        cursor.execute(query_init2)
        
        events = [
            (1, 'Шахматы', 'Межклассовый турнир по шахматам', 'к51', datetime(2025, 10, 29, 16, 30, 0), datetime(2025, 10, 29, 18, 30, 0), 'Сухофруктов Байрон 11У'),
            (2, 'СФТ', 'Турнир по футболу между двумя классами', 'спортзал', datetime(2025, 10, 30, 15, 30, 0), datetime(2025, 10, 30, 21, 30, 0), 'Рудаков Омлет 5Е'),
            (3, 'Дискотека', 'Дискотека в честь нового года', 'э11', datetime(2025, 10, 31, 16, 30, 0), datetime(2025, 10, 31, 19, 30, 0), 'Морозов Дед 99В'),
            (4, 'Родительское собрание', 'Конец света', 'к56', datetime(2025, 11, 1, 16, 30, 0), datetime(2025, 11, 1, 17, 30, 0), 'Сабвеев Михаил 35РФ')
        ]
        
        cursor.execute(query_check1)
        if cursor.fetchone()[0] == 0:
            cursor.executemany(query_indef1, events)
        
        users = [
            (1, 'Сухофруктов Байрон 11У', '+71621631880', 'aboba123#', 0),
            (2, 'Рудаков Омлет 5Е', '+71345561990', 'Qwerty', 1),
            (3, 'Морозов Дед 99В', '+74961229034', 'zvkvkvkzsvkzvkkv', 0),
            (4, 'Сабвеев Михаил 35РФ', '+79237653024', 'R3petit!vCymb@ll789', 1)
        ]  
        
        cursor.execute(query_check2)
        if cursor.fetchone()[0] == 0:
            cursor.executemany(query_indef2, users)

        db.commit()
        print("Database initialized with sample data")

    @app.route('/')
    @app.route('/table')
    def index():
        initialize_database()
    
        tables = get_table_names()
        table_data = {}
    
        for table in tables:
            columns, data = get_table_data(table)
            primary_key = get_primary_key(table)
            table_data[table] = {
                'columns': columns,
                'data': data,
                'primary_key': primary_key
            }
    
        return render_template('index.html', table_data=table_data)

    @app.route('/table/<table_name>')
    def show_table(table_name):
        columns, data = get_table_data(table_name)
        primary_key = get_primary_key(table_name)
        return render_template('details.html', 
                         table_name=table_name, 
                         columns=columns, 
                         data=data,
                         primary_key=primary_key)

    @app.route('/add_row/<table_name>')
    def add_row_form(table_name):
        schema = get_table_schema(table_name)
        primary_key = get_primary_key(table_name)
    
        form_fields = []
        for column in schema:
            if column['pk'] == 0:
                form_fields.append({
                    'name': column['name'],
                    'type': column['type'],
                    'notnull': column['notnull'],
                    'default_value': column['default_value']
                })
    
        return render_template('add_row.html', 
                         table_name=table_name, 
                         form_fields=form_fields,
                         primary_key=primary_key)

    @app.route('/insert_row/<table_name>', methods=['POST'])
    def insert_row_route(table_name):
        try:
            form_data = request.form.to_dict()
        
            schema = get_table_schema(table_name)
            for column in schema:
                if column['type'].upper() in ('TIMESTAMP', 'DATETIME') and column['name'] in form_data:
                    if form_data[column['name']]:
                        form_data[column['name']] = datetime.fromisoformat(form_data[column['name']].replace('T', ' '))
                    else:
                        form_data[column['name']] = None
        
            for column in schema:
                if column['type'].upper() in ('BOOLEAN', 'BOOL') and column['name'] in form_data:
                    form_data[column['name']] = bool(form_data[column['name']])
        
            for column in schema:
                if column['type'].upper() in ('INTEGER', 'INT') and column['name'] in form_data:
                    if form_data[column['name']]:
                        form_data[column['name']] = int(form_data[column['name']])
                    else:
                        form_data[column['name']] = None
        
            for column in schema:
                if column['type'].upper() in ('REAL', 'FLOAT', 'DOUBLE') and column['name'] in form_data:
                    if form_data[column['name']]:
                        form_data[column['name']] = float(form_data[column['name']])
                    else:
                        form_data[column['name']] = None
        
            if insert_row(table_name, form_data):
                flash(f'New row successfully added to {table_name}', 'success')
            else:
                flash('Error: Could not add new row', 'error')
            
        except Exception as e:
            flash(f'Error processing form data: {str(e)}', 'error')
    
        return redirect(url_for('index'))

    @app.route('/delete_row/<table_name>', methods=['POST'])
    def delete_row_route(table_name):
        primary_key = get_primary_key(table_name)
        primary_key_value = request.form.get('primary_key_value')
    
        if not primary_key:
            flash('Error: Could not identify primary key for this table', 'error')
            return redirect(url_for('index'))
    
        if delete_row(table_name, primary_key, primary_key_value):
            flash(f'Row successfully deleted from {table_name}', 'success')
        else:
            flash('Error: Could not delete row', 'error')
    
        referer = request.headers.get('Referer')
        if referer:
            return redirect(referer)
        else:
            return redirect(url_for('index'))

    @app.route('/add_sample_data')
    def add_sample_data():

        beg_time = datetime.now()
        end_time = beg_time + timedelta(hours=2)
        
        new_events = [
            ('Информационная безопасность', 'null', 'к00', beg_time + timedelta(days=7), end_time + timedelta(days=7), 'Тёмный Рыцарь 10Э',),
            ('Защита проектов от "Инженеров Будущего', 'null', 'к00', beg_time + timedelta(days=14), end_time + timedelta(days=7), 'Таранова Никоглада 18Н',),
            ('Консультация у психолога', 'null', 'к00', beg_time, end_time + timedelta(days=8), 'Личнова Псевдокия 66Ы',)
        ]
        
        events_query = """
            INSERT INTO events (id, name, desc, takeplace, datetime_beg, datetime_end, organizer)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        cursor.executemany(events_query, new_events)
        
        db.commit()
    
        flash('Sample data added successfully!', 'success')
        return redirect(url_for('index'))

    if __name__ == "__main__":
        app.run(debug=True)
from flask import Flask, render_template
import sqlite3
import datetime
from datetime import date, datetime, timedelta

app = Flask("myapp")

db_path = 'db/database.db'

with sqlite3.connect(db_path) as db:
    cursor = db.cursor()
    cursor.execute("""DROP TABLE events""")
    db.commit()
    cursor.execute("""DROP TABLE users""")
    db.commit()
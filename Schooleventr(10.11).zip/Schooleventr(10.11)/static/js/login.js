document.location.href = static/templates/login.html

const container = document.querySelector('.container');
const registerBtn = document.querySelector('.register-btn');
const loginBtn = document.querySelector('.login-btn');

registerBtn.addEventListener('click', () => {
    container.classList.add('active');
})

loginBtn.addEventListener('click', () => {
    container.classList.remove('active');
})

function setCookie(name, value, days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    const expires = "expires=" + date.toUTCString();
    document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for(let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function deleteCookie(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
}

function setUserCookie() {
    const userPhone = document.getElementById('userPhone').value.trim();
    
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userPhone: userPhone })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            setCookie('userName', data.userName, 7);
            alert('Cookie set successfully! Welcome ' + data.userName);
            document.getElementById('userPhone').value = '';
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error communicating with server');
    });
}

function getUserInfo() {
    const userName = getCookie('userName');
    const userInfoDiv = document.getElementById('userInfo');
    
    if (!userName) {
        userInfoDiv.innerHTML = '<p style="color: red;">No user cookie found. Please set your phone number first.</p>';
        return;
    }
    
    fetch(`/get-user?userName=${encodeURIComponent(userName)}`)
    .then(response => response.json())
    .then(data => {
        if (data.success && data.user) {
            userInfoDiv.innerHTML = `
                <h3>User Information:</h3>
                <p><strong>Name:</strong> ${data.user.name}</p>
                <p><strong>Phone:</strong> ${data.user.phone}</p>
                <p><strong>User ID:</strong> ${data.user.id}</p>
                <p><strong>Created:</strong> ${new Date(data.user.created_at).toLocaleString()}</p>
                <p><strong>Cookie Value (Name):</strong> ${userName}</p>
            `;
        } else {
            userInfoDiv.innerHTML = `<p style="color: red;">User not found in database: ${data.error}</p>`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        userInfoDiv.innerHTML = '<p style="color: red;">Error retrieving user information</p>';
    });
}
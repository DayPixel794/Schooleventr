from flask import Flask, render_template
import sqlite3
import datetime
from datetime import date, datetime, timedelta

app = Flask("myapp")

db_path = 'db/database.db'

with sqlite3.connect(db_path, check_same_thread=False) as db:
    cursor = db.cursor()

    #query_del1 = """DROP TABLE events"""
    #query_del2 = """DROP TABLE users"""
    query_init1 = """ CREATE TABLE IF NOT EXISTS events(
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT NOT NULL, 
        desc TEXT, 
        takeplace TEXT NOT NULL, 
        datetime_beg TIMESTAMP, 
        datetime_end TIMESTAMP, 
        organizer TEXT) """
    query_init2 = """ CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT NOT NULL,
        phone TEXT NOT NULL, 
        pwd TEXT NOT NULL,
        role INTEGER DEFAULT 0 
        )  """
    query_insert1 = """
            INSERT OR IGNORE INTO events (id, name, desc, takeplace, datetime_beg, datetime_end, organizer) VALUES (?, ?, ?, ?, ?, ?, ?)
            """
    query_insert2 = """
            INSERT OR IGNORE INTO users (id, name, phone, pwd, role) VALUES (?, ?, ?, ?, ?)
            """
    query_gtn = """SELECT name FROM sqlite_master WHERE type='table';"""
    query_gtb = """SELECT * FROM events"""

    def get_table_names():
        cursor.execute(query_gtn)
        tables = cursor.fetchall()
        return [table[0] for table in tables]

    def get_table_data(table_name):
        try:
            cursor.execute(query_gtb)
            columns = [description[0] for description in cursor.description]
            data = cursor.fetchall()
        except sqlite3.Error as e:
            print(f"Error reading table events: {e}")
            columns = []
            data = []
        
        return columns, data

    def initialize_database():
        
        # Create tables
        cursor.execute(query_init1)
        
        cursor.execute(query_init2)
        
        events = [
            (1, 'Шахматы', 'Межклассовый турнир по шахматам', 'к51', datetime(2025, 10, 29, 16, 30, 0), datetime(2025, 10, 29, 18, 30, 0), 'Сухофруктов Байрон 11У'),
            (2, 'СФТ', 'Турнир по футболу между двумя классами', 'спортзал', datetime(2025, 10, 30, 15, 30, 0), datetime(2025, 10, 30, 21, 30, 0), 'Рудаков Омлет 5Е'),
            (3, 'Дискотека', 'Дискотека в честь нового года', 'э11', datetime(2025, 10, 31, 16, 30, 0), datetime(2025, 10, 31, 19, 30, 0), 'Морозов Дед 99В'),
            (4, 'Родительское собрание', 'Конец света', 'к56', datetime(2025, 11, 1, 16, 30, 0), datetime(2025, 11, 1, 17, 30, 0), 'Сабвеев Михаил 35РФ')
        ]
        
        cursor.executemany(query_insert1, events)
        
        users = [
            (1, 'Сухофруктов Байрон 11У', '+71621631880', 'aboba123#', 0),
            (2, 'Рудаков Омлет 5Е', '+71345561990', 'Qwerty', 1),
            (3, 'Морозов Дед 99В', '+74961229034', 'zvkvkvkzsvkzvkkv', 0),
            (4, 'Сабвеев Михаил 35РФ', '+79237653024', 'R3petit!vCymb@ll789', 1)
        ]  
        
        cursor.executemany(query_insert2, users)

        db.commit()
        print("Database initialized with sample data")

    @app.route('/')
    @app.route('/table')
    def index():
        initialize_database()
    
        tables = get_table_names()
        table_data = {}
    
        for table in tables:
            columns, data = get_table_data(table)
            table_data[table] = {
                'columns': columns,
                'data': data
            }
    
        return render_template('index.html', table_data=table_data)

    @app.route('/table/<table_name>')
    def show_table(table_name):
        columns, data = get_table_data(table_name)
        return render_template('details.html', 
                         table_name=table_name, 
                         columns=columns, 
                         data=data)

    @app.route('/add_sample_data')
    def add_sample_data():

        beg_time = datetime.now()
        end_time = beg_time + timedelta(hours=2)
        
        new_events = [
            ('Информационная безопасность', 'null', 'к00', beg_time + timedelta(days=7), end_time + timedelta(days=7), 'Тёмный Рыцарь 10Э',),
            ('Защита проектов от "Инженеров Будущего', 'null', 'к00', beg_time + timedelta(days=14), end_time + timedelta(days=7), 'Таранова Никоглада 18Н',),
            ('Консультация у психолога', 'null', 'к00', beg_time, end_time + timedelta(days=8), 'Личнова Псевдокия 66Ы',)
        ]
        
        events_query = """
            INSERT INTO events (id, name, desc, takeplace, datetime_beg, datetime_end, org)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        cursor.executemany(events_query, new_events)
        
        db.commit()
    
        return "Sample data added successfully! <a href='/'>Back to main page</a>"

    if __name__ == "__main__":
        app.run(debug=True)
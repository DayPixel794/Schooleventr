from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import datetime
import os
from datetime import date, datetime, timedelta

app = Flask("myapp")
app.secret_key = os.urandom(64)

db_path = 'db/database.db'

with sqlite3.connect(db_path, check_same_thread=False) as db:
    cursor = db.cursor()

    #query_del1 = """DROP TABLE events"""
    #query_del2 = """DROP TABLE users"""
    query_init1 = """ CREATE TABLE IF NOT EXISTS events(
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT NOT NULL, 
        desc TEXT, 
        takeplace TEXT NOT NULL, 
        datetime_beg TIMESTAMP NOT NULL, 
        datetime_end TIMESTAMP NOT NULL, 
        organizer TEXT
        ) """
    query_init2 = """ CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT NOT NULL,
        phone TEXT NOT NULL, 
        pwd TEXT NOT NULL,
        role INTEGER DEFAULT 0 
        )  """
    query_check1 = """SELECT COUNT(*) FROM events"""
    query_check2 = """SELECT COUNT(*) FROM users"""
    query_info = """PRAGMA table_info({table_name})"""
    query_del = """DELETE FROM {table_name} WHERE {primary_key} = ?"""
    query_indef1 = """
            INSERT OR IGNORE INTO events (id, name, desc, takeplace, datetime_beg, datetime_end, organizer) VALUES (?, ?, ?, ?, ?, ?, ?)
            """
    query_indef2 = """
            INSERT OR IGNORE INTO users (id, name, phone, pwd, role) VALUES (?, ?, ?, ?, ?)
            """
    query_insert = """INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"""
    query_gtn = """SELECT name FROM sqlite_master WHERE type='table';"""
    query_gtd = """SELECT * FROM {table_name}"""

    def get_table_names():
        cursor.execute(query_gtn)
        tables = cursor.fetchall()
        return [table[0] for table in tables]

    def get_table_data(table_name):
        try:
            cursor.execute(f"""SELECT * FROM {table_name}""")
            columns = [description[0] for description in cursor.description]
            data = cursor.fetchall()
        except sqlite3.Error as e:
            print(f"Error reading table {table_name}: {e}")
            columns = []
            data = []
        
        return columns, data

    def get_primary_key(table_name):
        cursor.execute(f"""PRAGMA table_info({table_name})""")
        columns = cursor.fetchall()
        for column in columns:
            if column[5] == 1:
                return column[1]
        return None

    def get_table_schema(table_name):
        cursor.execute(f"""PRAGMA table_info({table_name})""")
        columns = cursor.fetchall()
        schema = []
        for column in columns:
            schema.append({
                'name': column[1],
                'type': column[2],
                'notnull': column[3],
                'default_value': column[4],
                'pk': column[5]
            })
        return schema

    def insert_row(table_name, data):
        try:
            schema = get_table_schema(table_name)
            primary_key = get_primary_key(table_name)
            
            filtered_data = {}
            for key, value in data.items():
                if key != primary_key:  
                    if value is not None and value != '':  
                        filtered_data[key] = value
            
            if not filtered_data:
                flash('Error: No valid data provided', 'error')
                return False
                
            columns = ', '.join(filtered_data.keys())
            placeholders = ', '.join(['?' for _ in filtered_data])
            query_into = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            
            print(f"Executing query: {query_into}")  # Debug
            print(f"With values: {list(filtered_data.values())}")  # Debug
            
            cursor.execute(query_into, list(filtered_data.values()))
            db.commit()
            return True
        except sqlite3.Error as e:
            print(f"Error inserting row: {e}")  # Debug
            db.rollback()
            return False
        
    def delete_row(table_name, primary_key, primary_key_value):
        try:
            cursor.execute(f"""DELETE FROM {table_name} WHERE {primary_key} = ?""", (primary_key_value,))
            db.commit()
            return True
        except sqlite3.Error as e:
            print(f"Error deleting row: {e}")
            db.rollback()
            return False

    def authenticate_user(phone, pwd):
        try:
            cursor.execute("SELECT * FROM users WHERE phone = ? AND pwd = ?", (phone, pwd))
            if not cursor.fetchone():
                return False
                print("Program error: user database is invalid")
            
            #cursor.execute("PRAGMA table_info(users)")
            #columns = [column[1] for column in cursor.fetchall()]
            #if 'pwd' not in columns:
                #print("Cannot find collumn: 'pwd'")
                #return False
            
            cursor.execute("SELECT * FROM users WHERE phone LIKE ? AND pwd LIKE ?", (f'%{phone}%', f'%{pwd}%'))
            user = cursor.fetchone()
            
            if user:
                return True
            else:
                return False
                print("Invalid phone or password")
            
        except sqlite3.Error as e:
            print(f"Authentication error: {e}")
            return False

    def initialize_user(name, phone, pwd,):
        try:
            cursor.execute("SELECT * FROM users WHERE name = ? AND phone = ? AND pwd = ?", (name, phone, pwd))
            if cursor.fetchone():
                return False
                print("Program error: user database is invalid")
            
            #cursor.execute("PRAGMA table_info(users)")
            #columns = [column[1] for column in cursor.fetchall()]
            #if 'pwd' not in columns:
                #print("Cannot find collumn: 'pwd'")
                #return False
            
            cursor.execute("SELECT * FROM users WHERE name LIKE ? AND phone LIKE ?", (f'%{name}%', f'%{phone}'))
            user = cursor.fetchone()
            
            if not(user):
                return True
            else:
                return False
                print("User already registered!")
            
        except sqlite3.Error as e:
            print(f"Authentication error: {e}")
            return False

    def initialize_database():
        
        cursor.execute(query_init1)
        
        cursor.execute(query_init2)
        
        events = [
            (1, 'Шахматы', 'Межклассовый турнир по шахматам', 'к51', datetime(2025, 10, 29, 16, 30, 0), datetime(2025, 10, 29, 18, 30, 0), 'Сухофруктов Байрон 11У'),
            (2, 'СФТ', 'Турнир по футболу между двумя классами', 'спортзал', datetime(2025, 10, 30, 15, 30, 0), datetime(2025, 10, 30, 21, 30, 0), 'Рудаков Омлет 5Е'),
            (3, 'Дискотека', 'Дискотека в честь нового года', 'э11', datetime(2025, 10, 31, 16, 30, 0), datetime(2025, 10, 31, 19, 30, 0), 'Морозов Дед 99В'),
            (4, 'Родительское собрание', 'Конец света', 'к56', datetime(2025, 11, 1, 16, 30, 0), datetime(2025, 11, 1, 17, 30, 0), 'Сабвеев Михаил 35РФ')
        ]
        
        cursor.execute(query_check1)
        if cursor.fetchone()[0] == 0:
            cursor.executemany(query_indef1, events)
        
        users = [
            (1, 'Сухофруктов Байрон 11У', '+71621631880', 'aboba123#', 0),
            (2, 'Рудаков Омлет 5Е', '+71345561990', 'Qwerty', 1),
            (3, 'Морозов Дед 99В', '+74961229034', 'zvkvkvkzsvkzvkkv', 0),
            (4, 'Сабвеев Михаил 35РФ', '+79237653024', 'R3petit!vCymb@ll789', 1)
        ]  
        
        cursor.execute(query_check2)
        if cursor.fetchone()[0] == 0:
            cursor.executemany(query_indef2, users)

        db.commit()
        print("Database initialized with sample data")

    @app.route('/')
    @app.route('/index')
    def index():
        initialize_database()
    
        tables = get_table_names()
        table_data = {}
    
        for table in tables:
            columns, data = get_table_data(table)
            primary_key = get_primary_key(table)
            table_data[table] = {
                'columns': columns,
                'data': data,
                'primary_key': primary_key
            }
    
        return render_template('index.html', table_data=table_data)

    @app.route('/portfolio')
    def portfolio():
        initialize_database()
    
        tables = get_table_names()
        table_data = {}
    
        for table in tables:
            columns, data = get_table_data(table)
            primary_key = get_primary_key(table)
            table_data[table] = {
                'columns': columns,
                'data': data,
                'primary_key': primary_key
            }
    
        return render_template('portfolio.html', table_data=table_data)

    @app.route('/contacts')
    def contacts():
        initialize_database()
    
        tables = get_table_names()
        table_data = {}
    
        for table in tables:
            columns, data = get_table_data(table)
            primary_key = get_primary_key(table)
            table_data[table] = {
                'columns': columns,
                'data': data,
                'primary_key': primary_key
            }
    
        return render_template('contacts.html', table_data=table_data)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if 'phone' in session:
            return redirect(url_for('index'))
    
        if request.method == 'POST':
            phone = request.form.get('phone')
            pwd = request.form.get('pwd')
        
            if not phone or not pwd:
                flash('Please enter both phone and password', 'error')
                return render_template('login.html')
        
            if authenticate_user(phone, pwd):
                session['phone'] = phone
                flash(f'Welcome back, {phone}!', 'success')
                return redirect(url_for('index'))
            else:
                flash('Invalid phone or password', 'error')
    
        return render_template('login.html')

    @app.route('/logout')
    def logout():
        session.pop('phone', None)
        flash('You have been logged out successfully', 'success')
        return redirect(url_for('index'))

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if 'phone' in session:
            return redirect(url_for('index'))
    
        if request.method == 'POST':
            name = request.form.get('name')
            phone = request.form.get('phone')
            pwd = request.form.get('pwd')
        
            if not phone or not pwd or not name:
                flash('Please enter your name, phone and password', 'error')
                return render_template('login.html')
        
            if initialize_user(name, phone, pwd):
                try:
                    form_data = request.form.to_dict()
                    print(f"Raw form data: {form_data}")  # Debug
        
                    processed_data = {}
                    schema = get_table_schema("users")
        
                    for column in schema:
                        col_name = column['name']
                        col_type = column['type'].upper()
            
                        if col_name in form_data:
                            value = form_data[col_name]

                        else:
                            value = '0'
                
                        if column['pk'] == 1:
                            continue
                
                        if value == '' and not column['notnull']:
                            processed_data[col_name] = None
                            continue
                
                        processed_data[col_name] = value if value else None
        
                    print(f"Processed data: {processed_data}")  # Debug
        
                    if insert_row("users", processed_data):
                        flash(f'New row successfully added to users', 'success')
                    else:
                        flash('Error: Could not add new row. Check the console for details.', 'error')
            
                except Exception as e:
                    print(f"Exception in insert_row_route: {str(e)}")  # Debug
                    flash(f'Error processing form data: {str(e)}', 'error')
    
                return redirect(url_for('admin'))
                flash(f'Successfully registered: {name}!', 'success')
                return redirect(url_for('login'))
            else:
                flash(("User already registered!"), 'error')
    
        return render_template('login.html')
    
    @app.route('/admin')
    @app.route('/admin/table')
    def admin():
        initialize_database()
    
        tables = get_table_names()
        table_data = {}
    
        for table in tables:
            columns, data = get_table_data(table)
            primary_key = get_primary_key(table)
            table_data[table] = {
                'columns': columns,
                'data': data,
                'primary_key': primary_key
            }
    
        return render_template('admin.html', table_data=table_data)

    @app.route('/admin/table/<table_name>')
    def show_table(table_name):
        columns, data = get_table_data(table_name)
        primary_key = get_primary_key(table_name)
        return render_template('table_detail.html', 
                         table_name=table_name, 
                         columns=columns, 
                         data=data,
                         primary_key=primary_key)

    @app.route('/admin/add_row/<table_name>')
    def add_row_form(table_name):
        schema = get_table_schema(table_name)
        primary_key = get_primary_key(table_name)
    
        form_fields = []
        for column in schema:
            if column['pk'] == 0:
                form_fields.append({
                    'name': column['name'],
                    'type': column['type'],
                    'notnull': column['notnull'],
                    'default_value': column['default_value']
                })
    
        return render_template('add_row.html', 
                         table_name=table_name, 
                         form_fields=form_fields,
                         primary_key=primary_key)

    @app.route('/admin/insert_row/<table_name>', methods=['POST'])
    def insert_row_route(table_name):
        try:
            form_data = request.form.to_dict()
            print(f"Raw form data: {form_data}")  # Debug
        
            processed_data = {}
            schema = get_table_schema(table_name)
        
            for column in schema:
                col_name = column['name']
                col_type = column['type'].upper()
            
                if col_name in form_data:
                    value = form_data[col_name]
                
                if column['pk'] == 1:
                    continue
                
                if value == '' and not column['notnull']:
                    processed_data[col_name] = None
                    continue
                
                if col_type in ('TIMESTAMP', 'DATETIME'):
                    if value:
                        processed_data[col_name] = value.replace('T', ' ') + ':00'
                    else:
                        processed_data[col_name] = None
                
                elif col_type in ('BOOLEAN', 'BOOL'):
                    if value == 'true':
                        processed_data[col_name] = 1
                    elif value == 'false':
                        processed_data[col_name] = 0
                    else:
                        processed_data[col_name] = None
                
                elif col_type in ('INTEGER', 'INT'):
                    if value:
                        processed_data[col_name] = int(value)
                    else:
                        processed_data[col_name] = None
                
                elif col_type in ('REAL', 'FLOAT', 'DOUBLE'):
                    if value:
                        processed_data[col_name] = float(value)
                    else:
                        processed_data[col_name] = None
                
                else:  # TEXT and others
                    processed_data[col_name] = value if value else None
        
            print(f"Processed data: {processed_data}")  # Debug
        
            for column in schema:
                if column['notnull'] and column['pk'] == 0: 
                    if column['name'] not in processed_data or processed_data[column['name']] is None:
                        flash(f'Error: Required field is missing')
                        return redirect(url_for('add_row_form', table_name=table_name))
        
            if insert_row(table_name, processed_data):
                flash(f'New row successfully added to {table_name}', 'success')
            else:
                flash('Error: Could not add new row. Check the console for details.', 'error')
            
        except Exception as e:
            print(f"Exception in insert_row_route: {str(e)}")  # Debug
            flash(f'Error processing form data: {str(e)}', 'error')
    
        return redirect(url_for('admin'))

    @app.route('/admin/delete_row/<table_name>', methods=['POST'])
    def delete_row_route(table_name):
        primary_key = get_primary_key(table_name)
        primary_key_value = request.form.get('primary_key_value')
    
        if not primary_key:
            flash('Error: Could not identify primary key for this table', 'error')
            return redirect(url_for('admin'))
    
        if delete_row(table_name, primary_key, primary_key_value):
            flash(f'Row successfully deleted from {table_name}', 'success')
        else:
            flash('Error: Could not delete row', 'error')
    
        referer = request.headers.get('Referer')
        if referer:
            return redirect(referer)
        else:
            return redirect(url_for('admin'))

    @app.route('/admin/add_sample_data')
    def add_sample_data():

        beg_time = datetime.now()
        end_time = beg_time + timedelta(hours=2)
        
        new_events = [
            ('Информационная безопасность', 'null', 'к00', beg_time + timedelta(days=7), end_time + timedelta(days=7), 'Тёмный Рыцарь 10Э',),
            ('Защита проектов от "Инженеров Будущего', 'null', 'к00', beg_time + timedelta(days=14), end_time + timedelta(days=7), 'Таранова Никоглада 18Н',),
            ('Консультация у психолога', 'null', 'к00', beg_time, end_time + timedelta(days=8), 'Личнова Псевдокия 66Ы',)
        ]
        
        events_query = """
            INSERT INTO events (name, desc, takeplace, datetime_beg, datetime_end, organizer)
            VALUES (?, ?, ?, ?, ?, ?)
        """
        cursor.executemany(events_query, new_events)
        
        db.commit()
    
        flash('Sample data added successfully!', 'success')
        return redirect(url_for('admin'))

    if __name__ == "__main__":
        app.run(debug=True)
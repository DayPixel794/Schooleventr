import sqlite3
import datetime
import os
from flask import Flask, render_template, url_for

app = Flask("myapp")

db = 'database.db'

def get_timestamp(y,m,d,h,mn):
    return datetime.datetime.timestamp(datetime.datetime(y,m,d,h,mn,sec))

def get_date(tmstmp):
    return datetime.datetime.fromtimestamp(tmstmp).date()

events = [
    (1, 'Шахматы', 'Межклассовый турнир по шахматам', 'к51', get_timestamp(2025, 10, 29, 16, 30), get_timestamp(2025, 10, 29, 18, 30), 'Сухофруктов Байрон 11У'),
    (2, 'СФТ', 'Турнир по футболу между двумя классами', 'спортзал', get_timestamp(2025, 10, 30, 15, 30), get_timestamp(2025, 10, 30, 21, 30), 'Рудаков Омлет 5Е'),
    (3, 'Дискотека', 'Дискотека в честь нового года', 'э11', get_timestamp(2025, 10, 31, 16, 30), get_timestamp(2025, 10, 31, 19, 30), 'Морозов Дед 99В'),
    (4, 'Родительское собрание', 'Конец света', 'к56', get_timestamp(2025, 11, 1, 16, 30), get_timestamp(2025, 11, 1, 17, 30), 'Сабвеев Михаил 35РФ')
]

users = [
    (1, 'Сухофруктов Байрон 11У', '+71621631880', 'aboba123#'),
    (2, 'Рудаков Омлет 5Е', '+71345561990', 'Qwerty'),
    (3, 'Морозов Дед 99В', '+74961229034', 'zvkvkvkzsvkzvkkv'),
    (4, 'Сабвеев Михаил 35РФ', '+79237653024', 'R3petit!vCymb@ll789')
]

volunteers = [

]

participants_us = [

]

volunteers_us = [

]

#drt = datetime.datetime(2025,10,29)
#print(drt, 'drt')
#dts = datetime.datetime.timestamp(drt)
#print(int(dts), 'dts')
#print('good read', datetime.datetime.fromtimestamp(dts).date())

with sqlite3.connect('db/database.db') as db:
    cursor = db.cursor()

    #TABLE events

    events_q1 = """ CREATE TABLE IF NOT EXISTS events(id INTEGER, name TEXT, desc TEXT, takeplace TEXT, datetime_beg INTEGER, datetime_end INTEGER, organizer TEXT) """
    events_q2 = """ INSERT INTO events(id, name, desc, takeplace, datetime_beg, datetime_end, organizer) VALUES(?,?,?,?,?,?,?); """
    events_q3 = """ SELECT * FROM events """
    events_q4 = """ DELETE FROM events """
    events_q5 = """ DROP TABLE IF EXISTS events"""
    evdisplay_q1 = """ SELECT events.id, datetime_beg, users.name FROM events JOIN users USING(id) WHERE id <=2 """
    db.commit()

    #cursor.execute(events_q5)
    #cursor.execute(events_q1)
    #cursor.executemany(events_q2, events)

    cursor.execute(events_q3)
    items = cursor.fetchall()

    #print(items[0])

    #cursor.execute(evdisplay_q1)
    #for res in cursor:
        #print(res[0], res[1], res[2]) 
    #db.commit()

    #TABLE users

    users_q1 = """ CREATE TABLE IF NOT EXISTS users(id INTEGER, name TEXT, phone TEXT, pwd TEXT) """
    users_q2 = """ INSERT INTO users(id, name, phone, pwd) VALUES(?,?,?,?); """
    users_q3 = """ SELECT * FROM users """
    users_q4 = """ DELETE FROM users """
    db.commit()

    #cursor.execute(users_q1)
    #cursor.executemany(users_q2, users)
    #db.commit()

    #print_items()

    